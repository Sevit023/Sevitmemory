# SPDX-FileCopyrightText: 2019 citron Emulator Project
# SPDX-License-Identifier: GPL-2.0-or-later

git config --global user.email "zephyron@citron-emu.org"
git config --global user.name "Zephyron"
